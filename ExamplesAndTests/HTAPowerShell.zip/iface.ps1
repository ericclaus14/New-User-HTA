﻿Get-NetRoute -DestinationPrefix 0.0.0.0/0|clip
echo "Hi we are done"